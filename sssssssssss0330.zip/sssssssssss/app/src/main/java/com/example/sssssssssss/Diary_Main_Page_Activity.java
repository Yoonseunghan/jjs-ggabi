package com.example.sssssssssss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Diary_Main_Page_Activity extends AppCompatActivity {

    private CalendarView mCalendarView;
    private TextView mTextView;
    private DrawerLayout drawerLayout;
    private View drawerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_home_page);

        mCalendarView = findViewById(R.id.main_calender);
        mTextView = findViewById(R.id.main_calender_text);

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = year + "년 " + (month+1) + "월 " + dayOfMonth + "일";
                mTextView.setText(date);
            }
        });


        //공유일기 버튼을 눌렀을 때 공유일기 화면으로 넘어가는 코드
        Button shareButton = findViewById(R.id.share_button);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Diary_Main_Page_Activity.this, Shared_Create_Join_Page_Activity.class);
                startActivity(intent);
            }
        });//공유일기 버튼을 눌렀을 때 공유일기 화면으로 넘어가는 코드 끝


        //공유일기 검색 버튼을 눌렀을 때 검색 화면 전환
        ImageButton main_search_button = findViewById(R.id.main_search_button);
        main_search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Diary_Main_Page_Activity.this, Search_Words_Activity.class);
                startActivity(intent);
            }
        });//공유일기 검색 버튼을 눌렀을 때 검색 화면 전환 끝


        //설정 버튼 누르면 설정 화면 전환
        Button setting_button = findViewById(R.id.setting_button);
        setting_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Diary_Main_Page_Activity.this, Setting_Page_Activity.class);
                startActivity(intent);
            }
        });//설정 버튼 누르면 설정 화면 전환 끝


        //우측 하단 일기 작성 버튼
        FloatingActionButton fabButton = findViewById(R.id.btn_main_write);
        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Diary_Main_Page_Activity.this, Main_Write_Activity.class);
                startActivity(intent);
            }
        });//우측 하단 일기 작성 버튼 끝


// 공유방 메인에서 왼쪽 이미지버튼은 share.xml로, 오른쪽 이미지버튼은 share2.xml로 연결되게 한것
// 닫기버튼 누른것처럼 각 버튼 눌렀을때 준식이형이 만든 화면으로 전환되는것 해야함.
// 일기쓰기 버튼 어디에 추가할지 정해야함
        drawerLayout = findViewById(R.id.main_drawer_layout);
        drawerView = findViewById(R.id.main_left_drawer);

        ImageButton btn_open = findViewById(R.id.main_list_button);
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(drawerView);
            }
        });

        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        drawerLayout.addDrawerListener(listener);

    }

    DrawerLayout.DrawerListener listener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }

    };
}


