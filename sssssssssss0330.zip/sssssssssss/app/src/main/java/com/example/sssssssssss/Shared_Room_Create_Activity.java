package com.example.sssssssssss;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Shared_Room_Create_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shared_roomcreate);

//        EditText createTitle = findViewById(R.id.create_title);
//        EditText createCode = findViewById(R.id.create_code);
//        EditText createPwd = findViewById(R.id.create_pwd);
        Button createBtn = findViewById(R.id.create_btn);

//        TextWatcher inputTextWatcher = new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                // 입력 내용이 변경되기 전에 호출됩니다.
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                // 입력 내용이 변경될 때마다 호출됩니다.
//                String title = createTitle.getText().toString().trim();
//                String code = createCode.getText().toString().trim();
//                String pwd = createPwd.getText().toString().trim();
//
//                if (!title.isEmpty() && !code.isEmpty() && !pwd.isEmpty()) {
//                    createBtn.setEnabled(true);
//                } else {
//                    createBtn.setEnabled(false);
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                // 입력 내용이 변경된 후에 호출됩니다.
//            }
//        };
//
//        createTitle.addTextChangedListener(inputTextWatcher);
//        createCode.addTextChangedListener(inputTextWatcher);
//        createPwd.addTextChangedListener(inputTextWatcher);

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Shared_Room_Create_Activity.this, Shared_Create_Join_Page_Activity.class);
                startActivity(intent);
            }
        });

        //        닫기 기능 코드
        Button closeButton2 = findViewById(R.id.btn_close1);
        closeButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // 닫기 기능 실행
            }
        });
        //        닫기 기능 코드 끝

    }

}
