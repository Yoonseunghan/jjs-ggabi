package com.example.sssssssssss;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class Written_Shared_Diary_Activity extends AppCompatActivity {
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shared_writtenshareddiary_page);

        //        뒤로가기 기능
        ImageButton backButton = findViewById(R.id.btn_back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // 뒤로가기 기능 실행
            }
        });
        //        뒤로가기 기능 코드 끝

        viewPager = findViewById(R.id.viewPager);
        Diary_Image_Upload_Activity adapter = new Diary_Image_Upload_Activity(this);
        viewPager.setAdapter(adapter);

        viewPager.setClipToPadding(false);

        viewPager.setPadding(100, 0, 100, 0);
        viewPager.setPageMargin(50);
    }
}
