package com.example.sssssssssss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

public class Shared_Main_Page_Activity extends AppCompatActivity {
    private CalendarView mCalendarView;
    private TextView mTextView;
    private DrawerLayout drawerLayout;
    private View drawerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sharedmainpage);

        mCalendarView = findViewById(R.id.main_calender);
        mTextView = findViewById(R.id.textView);

        Spinner spinner = findViewById(R.id.name_spinner);

        // Spinner에 표시할 항목 배열
        String[] items = {"가족방", "친구방", "게임방", "방방"};

        // ArrayAdapter를 이용하여 항목 배열을 Spinner에 연결
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = year + "년 " + (month+1) + "월 " + dayOfMonth + "일";
                mTextView.setText(date);
            }
        });


//공유일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드
        Button individual_button = findViewById(R.id.individual_button);
        individual_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shared_Main_Page_Activity.this, Diary_Main_Page_Activity.class);
                startActivity(intent);
            }
        });//공유일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드 끝



        //공유일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드
        ImageButton saerch_button = findViewById(R.id.saerch_button);
        saerch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shared_Main_Page_Activity.this, Search_Name_Activity.class);
                startActivity(intent);
            }
        });//공유일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드 끝

        //설정버튼 누르면 설정 화면 전환
        Button setting_botton = findViewById(R.id.setting_botton);
        setting_botton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shared_Main_Page_Activity.this, Setting_Page_Activity.class);
                startActivity(intent);
            }
        });//설정버튼 누르면 설정 화면 전환 끝



// 공유방 메인에서 왼쪽 이미지버튼은 share.xml로, 오른쪽 이미지버튼은 share2.xml로 연결되게 한것
// 닫기버튼 누른것처럼 각 버튼 눌렀을때 준식이형이 만든 화면으로 전환되는것 해야함.
// 일기쓰기 버튼 어디에 추가할지 정해야함
        drawerLayout = findViewById(R.id.shared_drawer_layout);
        drawerView = findViewById(R.id.shared_left_drawer);
        View drawerView2 = findViewById(R.id.shared_right_drawer);

        ImageButton btn_open = findViewById(R.id.btn_open);
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(drawerView);
            }
        });

        ImageButton btn_open2 = findViewById(R.id.btn_open2);
        btn_open2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(drawerView2);
            }
        });

        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        drawerLayout.addDrawerListener(listener);
    }

    DrawerLayout.DrawerListener listener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }

    };
}
