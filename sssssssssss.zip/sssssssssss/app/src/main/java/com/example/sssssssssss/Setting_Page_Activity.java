package com.example.sssssssssss;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Setting_Page_Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settingpage);



        //        뒤로가기 기능
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // 뒤로가기 기능 실행
            }
        });
//        뒤로가기 기능 코드 끝

//내정보 편집 버튼 클릭하면 내정보 화면으로 이동하는 코드
        Button myInfoButton = findViewById(R.id.information_setting_button);
        myInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Setting_Page_Activity.this, My_information_Activity.class);
                startActivity(intent);
            }
        }); //내정보 편집 버튼 클릭하면 내정보 화면으로 이동하는 코드 끝

//
        //내정보 편집 버튼 클릭하면 내정보 화면으로 이동하는 코드
        Button alarmButton = findViewById(R.id.alarm_setting_button);
        alarmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Setting_Page_Activity.this, Alarm_Activity.class);
                startActivity(intent);
            }
        }); //내정보 편집 버튼 클릭하면 내정보 화면으로 이동하는 코드 끝




        //잠금 스위치 토스트메시지와, 기능 죽이기 설정 준식
        Switch lockSwitch = findViewById(R.id.lock_switch);
        Switch passwordSwitch = findViewById(R.id.password_switch);
        Switch patternSwitch = findViewById(R.id.patton_switch);
        Switch fingerprintSwitch = findViewById(R.id.Fingerprint_switch);

        lockSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String message = isChecked ? "잠금이 비활성화 됐습니다." : "잠금이 활성화 됐습니다.";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();

                if (isChecked) {
                    passwordSwitch.setVisibility(View.GONE);
                    patternSwitch.setVisibility(View.GONE);
                    fingerprintSwitch.setVisibility(View.GONE);

                    passwordSwitch.setEnabled(false);
                    patternSwitch.setEnabled(false);
                    fingerprintSwitch.setEnabled(false);

                } else {
                    passwordSwitch.setVisibility(View.VISIBLE);
                    patternSwitch.setVisibility(View.VISIBLE);
                    fingerprintSwitch.setVisibility(View.VISIBLE);

                    passwordSwitch.setEnabled(true);
                    patternSwitch.setEnabled(true);
                    fingerprintSwitch.setEnabled(true);
                }
            }
        });//잠금 스위치 토스트메시지와, 기능 죽이기 설정 끝



        // 알림 비활성화 스위치 준식
        Switch alarmSwitch = findViewById(R.id.alarm_switch);
        LinearLayout alarmSettingLayout = findViewById(R.id.alarm_setting);
        Button alarmSettingButton = findViewById(R.id.alarm_setting_button);

        alarmSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String message = isChecked ? "알림이 비활성화 됐습니다." : "알림이 활성화 됐습니다.";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                
                if (isChecked) {
                    alarmSettingLayout.setVisibility(View.GONE);
                    alarmSettingButton.setEnabled(false);
                }
                else {
                    alarmSettingLayout.setVisibility(View.VISIBLE);
                    alarmSettingButton.setEnabled(true);
                }
            }
        });



    }}