package com.example.sssssssssss;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class Search_Name_Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchname);



        //        뒤로가기 기능
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // 뒤로가기 기능 실행
            }
        });
//        뒤로가기 기능 코드 끝




// Spinner에 표시할 항목 배열 준식 작성
        Spinner spinner = findViewById(R.id.name_spinner);
        String[] items = {"고태웅", "김승진", "김준식", "윤승한"};

// ArrayAdapter를 이용하여 항목 배열을 Spinner에 연결
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);






    }}