package com.example.sssssssssss;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;

//전체 준식 작성
public class Alarm_Activity extends AppCompatActivity {

    private ListView mAlarmListView;
    private ArrayAdapter<String> mAdapter;
    private ArrayList<String> mAlarmList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alarm);

        mAlarmListView = findViewById(R.id.alarm_list_view);
        mAlarmList = new ArrayList<>();
        mAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mAlarmList);
        mAlarmListView.setAdapter(mAdapter);



//       뒤로가기 버튼 기능
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        // 뒤로가기 기능 코드 끝




        //길게누르면 목록 삭제
        mAlarmListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                mAlarmList.remove(position);
                mAdapter.notifyDataSetChanged();
                return true;
            }
        });
        //길게 누르면 목록삭제 코드 끝


        //삭제 될 때 "알림이 삭제되었습니다." 나타나는 토스트메시지.
        mAlarmListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                mAlarmList.remove(position);
                mAdapter.notifyDataSetChanged();
                Toast.makeText(Alarm_Activity.this, "알림이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        //삭제 될 때 "알림이 삭제되었습니다." 나타나는 토스트메시지. 끝


        Button addButton = findViewById(R.id.add_Alarm);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 시간 선택 처리
                TimePicker timePicker = findViewById(R.id.time_picker);
                int hour = timePicker.getHour();
                int minute = timePicker.getMinute();
                String time = hour + ":" + minute;

                // 요일 선택 처리
                String day = "";
                CheckBox mondayCheckBox = findViewById(R.id.monday_checkbox);
                CheckBox tuesdayCheckBox = findViewById(R.id.tuesday_checkbox);
                CheckBox wednesdayCheckBox = findViewById(R.id.wednesday_checkbox);
                CheckBox thursdayCheckBox = findViewById(R.id.thursday_checkbox);
                CheckBox fridayCheckBox = findViewById(R.id.friday_checkbox);
                CheckBox saturdayCheckBox = findViewById(R.id.saturday_checkbox);
                CheckBox sundayCheckBox = findViewById(R.id.sunday_checkbox);

                boolean isEveryday = false; // 모든 요일이 선택되었는지 확인하는 변수
                if (mondayCheckBox.isChecked() && tuesdayCheckBox.isChecked() && wednesdayCheckBox.isChecked()
                        && thursdayCheckBox.isChecked() && fridayCheckBox.isChecked() && saturdayCheckBox.isChecked()
                        && sundayCheckBox.isChecked()) {
                    day = "매일";
                    isEveryday = true;
                } else {
                    // 선택된 요일들을 문자열로 나타내기
                    if (mondayCheckBox.isChecked()) {
                        day += "월요일 ";
                    }
                    if (tuesdayCheckBox.isChecked()) {
                        day += "화요일 ";
                    }
                    if (wednesdayCheckBox.isChecked()) {
                        day += "수요일 ";
                    }
                    if (thursdayCheckBox.isChecked()) {
                        day += "목요일 ";
                    }
                    if (fridayCheckBox.isChecked()) {
                        day += "금요일 ";
                    }
                    if (saturdayCheckBox.isChecked()) {
                        day += "토요일 ";
                    }
                    if (sundayCheckBox.isChecked()) {
                        day += "일요일 ";
                    }
                }

                // 알림 추가
                if (!day.equals("")) {
                    String alarm;
                    if (isEveryday) {
                        alarm = time + " " + day;
                    } else {
                        alarm = time + " " + day.trim();
                    }
                    mAlarmList.add(alarm);
                    mAdapter.notifyDataSetChanged();
                }
            }

        });


    }


}
