package com.example.sssssssssss;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Shared_Room_Join_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sharedroomjoin);

//        EditText createCode2 = findViewById(R.id.create_code2);
//        EditText createPwd2 = findViewById(R.id.create_pwd2);
        Button createBtn2 = findViewById(R.id.create_btn2);

//        TextWatcher inputTextWatcher = new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                // 입력 내용이 변경되기 전에 호출됩니다.
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                // 입력 내용이 변경될 때마다 호출됩니다.
//                String code = createCode2.getText().toString().trim();
//                String pwd = createPwd2.getText().toString().trim();
//
//                if (!code.isEmpty() && !pwd.isEmpty()) {
//                    createBtn2.setEnabled(true);
//                } else {
//                    createBtn2.setEnabled(false);
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                // 입력 내용이 변경된 후에 호출됩니다.
//            }

//        createCode2.addTextChangedListener(inputTextWatcher);
//        createPwd2.addTextChangedListener(inputTextWatcher);

        createBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Shared_Room_Join_Activity.this, Shared_Create_Join_Page_Activity.class);
                startActivity(intent);
            }
        });

        };



    }

