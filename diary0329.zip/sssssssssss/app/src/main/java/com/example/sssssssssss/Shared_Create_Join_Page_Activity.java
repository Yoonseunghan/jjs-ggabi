package com.example.sssssssssss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class Shared_Create_Join_Page_Activity extends AppCompatActivity {
    private TextView mTextView;
    private DrawerLayout drawerLayout;
    private View drawerView;

    private ImageButton btnCreate, btnJoin; // 상단의 각각 메뉴, 생성, 참가 버튼 변수 선언

    private BottomSheetDialog bottomSheetDialog; // 생성, 참가 버튼 클릭 시 하단에서 화면을 생성시키는 BottomSheetDialog 변수 선언

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sharedcreatejoinpage);

        mTextView = findViewById(R.id.textView);


        //개인일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드
        Button individual_button = findViewById(R.id.individual_button);
        individual_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shared_Create_Join_Page_Activity.this, Diary_Main_Page_Activity.class);
                startActivity(intent);
            }
        });//개인일기 버튼을 눌렀을때 개인일기 화면으로 넘어가는 코드 끝

        // 방 생성 버튼에 클릭 리스너 설정
        btnCreate = findViewById(R.id.btn_create);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // BottomSheetDialog 객체 생성
                bottomSheetDialog = new BottomSheetDialog(Shared_Create_Join_Page_Activity.this);

                // BottomSheetDialog에 사용할 View 객체 생성
                View bottomSheetView = getLayoutInflater().inflate(R.layout.sharedroomcreate, null);

                // BottomSheetDialog에 View 객체 설정
                bottomSheetDialog.setContentView(bottomSheetView);

                // BottomSheetDialog를 화면에 표시
                bottomSheetDialog.show();
            }
        });

        // 방 참가 버튼에 클릭 리스너 설정
        btnJoin = findViewById(R.id.btn_join);
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // BottomSheetDialog 객체 생성
                bottomSheetDialog = new BottomSheetDialog(Shared_Create_Join_Page_Activity.this);

                // BottomSheetDialog에 사용할 View 객체 생성
                View bottomSheetView = getLayoutInflater().inflate(R.layout.sharedroomjoin, null);

                // BottomSheetDialog에 View 객체 설정
                bottomSheetDialog.setContentView(bottomSheetView);

                // BottomSheetDialog를 화면에 표시
                bottomSheetDialog.show();
            }
        });


        // 임시 가족 일기장
        Button btnTest2 = findViewById(R.id.btn_test2);
        btnTest2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Shared_Create_Join_Page_Activity.this, Shared_Main_Page_Activity.class);
                startActivity(intent);
            }
        });

// 공유방 메인에서 왼쪽 이미지버튼은 share.xml로, 오른쪽 이미지버튼은 share2.xml로 연결되게 한것
// 닫기버튼 누른것처럼 각 버튼 눌렀을때 준식이형이 만든 화면으로 전환되는것 해야함.
// 일기쓰기 버튼 어디에 추가할지 정해야함
        drawerLayout = findViewById(R.id.shared_drawer_layout);
        drawerView = findViewById(R.id.shared_left_drawer);

        ImageButton btn_open = findViewById(R.id.btn_open);
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(drawerView);
            }
        });

        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        drawerLayout.addDrawerListener(listener);
    }

    DrawerLayout.DrawerListener listener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }

    };
}
