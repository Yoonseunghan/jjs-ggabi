package com.example.sssssssssss;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class Written_Shared_Diary_Activity extends AppCompatActivity {
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.writtenshareddiary);

        viewPager = findViewById(R.id.viewPager);
        Diary_Image_Upload_Activity adapter = new Diary_Image_Upload_Activity(this);
        viewPager.setAdapter(adapter);

        viewPager.setClipToPadding(false);

        viewPager.setPadding(100, 0, 100, 0);
        viewPager.setPageMargin(50);
    }
}
